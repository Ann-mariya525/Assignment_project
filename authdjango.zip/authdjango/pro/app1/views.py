from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
# Create your views here.
from django.http import HttpResponse
from django.contrib.auth import authenticate,login,logout
from app1.forms import userForm

from django.shortcuts import render, redirect
from django.views.generic import ListView, DetailView, CreateView
from .models import Question, Answer, Like

def home(request):
    return render(request,'home.html')

# def signUp1(request):
#     form = userForm()
#     if(request.method=='POST'):
#         form = userForm(request.POST)
#         if form.is_valid():
#             form.save()
#             return home(request)

#     return render(request,'signup1.html',{"form": form})



def base(request):
    return render(request,'base.html')



#######################################################################
def home(request):

    return render(request, 'home.html')
def base(request):
    return render(request,'base.html')


def signUp1(request):
   form = UserCreationForm()
   if(request.method=='POST'):
       form = UserCreationForm(request.POST)
       if form.is_valid():
           form.save()
           return home(request)

   return render(request, 'signup1.html', {"form": form})
########################################################################
def user_login1(request):
    if(request.method=="POST"):
        name = request.POST['n']
        password = request.POST['p']
        user = authenticate(username=name, password=password)
        if user:
            login(request,user)
            
            return home(request)
      
        else:
             return HttpResponse('invalid ...no user found')
    return render(request, 'login1.html')

def user_logout1(request):
        logout(request)
        return user_login1(request)
######


# class QuestionListView(ListView):
#     model = Question
#     template_name = 'question_list.html'
#     context_object_name = 'questions'
def QuestionListView(request):
    data=Question.objects.all()
    return render(request,'question_list.html',{'questions':data})

class QuestionDetailView(DetailView):
    model = Question
    template_name = 'question_detail.html'
    context_object_name = 'question'

class QuestionCreateView(CreateView):
    model = Question
    template_name = 'question_form.html'
    fields = ['text']

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

def answer_question(request, question_id):
    question = Question.objects.get(pk=question_id)
    if request.method == 'POST':
        text = request.POST.get('text')
        Answer.objects.create(author=request.user, question=question, text=text)
        return redirect('question_detail', question_id=question_id)
    return render(request, 'answer_form.html', {'question': question})

def like_answer(request, answer_id):
    answer = Answer.objects.get(pk=answer_id)
    Like.objects.create(user=request.user, answer=answer)
    return redirect('question_detail', question_id=answer.question.id)
